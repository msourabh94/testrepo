#!/usr/bin/env bash

mvn install:install-file \
-Dfile=lib/hypersistence-optimizer-2.1.1-trial.jar \
-Dsources=lib/hypersistence-optimizer-2.1.1-trial-sources.jar \
-Djavadoc=lib/hypersistence-optimizer-2.1.1-trial-javadoc.jar \
-DgroupId=io.hypersistence \
-DartifactId=hypersistence-optimizer \
-Dversion=2.1.1-trial \
-Dpackaging=jar \
-DgeneratePom=true

mvn install:install-file \
-Dfile=lib/hypersistence-optimizer-2.1.1-trial-jre6.jar \
-Dsources=lib/hypersistence-optimizer-2.1.1-trial-jre6-sources.jar \
-Djavadoc=lib/hypersistence-optimizer-2.1.1-trial-jre6-javadoc.jar \
-DgroupId=io.hypersistence \
-DartifactId=hypersistence-optimizer \
-Dversion=2.1.1-trial-jre6 \
-Dpackaging=jar \
-DgeneratePom=true