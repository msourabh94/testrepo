Hypersistence Optimizer - Version 2.1.1-trial - Built on 2020-05-25
================================================================================

Hypersistence Optimizer is a dynamic analyzing tool that can scan your JPA and Hibernate application and provide you tips about the changes you need to make to entity mappings, configurations, queries, and Persistence Context actions to speed up your data access layer.

Once you downloaded the Full or Trial version, you need to follow a series of steps in order to install Hypersistence Optimizer.

Unzipping the package
=====================

The first thing you need to do is to unzip the package you have just downloaded.

> unzip hypersistence-optimizer-2.1.1-trial-pack.zip

After unzipping the project package, you will get the following file structure:

creating: hypersistence-optimizer-2.1.1-trial/
   creating: hypersistence-optimizer-2.1.1-trial/lib/
  inflating: hypersistence-optimizer-2.1.1-trial/lib/hypersistence-optimizer-2.1.1-trial-javadoc.jar
  inflating: hypersistence-optimizer-2.1.1-trial/lib/hypersistence-optimizer-2.1.1-trial-sources.jar
  inflating: hypersistence-optimizer-2.1.1-trial/lib/hypersistence-optimizer-2.1.1-trial.jar
   creating: hypersistence-optimizer-2.1.1-trial/configs/
   creating: hypersistence-optimizer-2.1.1-trial/configs/META-INF/
   creating: hypersistence-optimizer-2.1.1-trial/configs/META-INF/services/
  inflating: hypersistence-optimizer-2.1.1-trial/configs/META-INF/services/org.hibernate.boot.spi.SessionFactoryBuilderFactory
   creating: hypersistence-optimizer-2.1.1-trial/docs/
   creating: hypersistence-optimizer-2.1.1-trial/docs/html/
   creating: hypersistence-optimizer-2.1.1-trial/docs/pdf/
  inflating: hypersistence-optimizer-2.1.1-trial/docs/html/asciidoctor.css
  inflating: hypersistence-optimizer-2.1.1-trial/docs/html/coderay-asciidoctor.css
  inflating: hypersistence-optimizer-2.1.1-trial/docs/pdf/InstallationGuide.pdf
  inflating: hypersistence-optimizer-2.1.1-trial/docs/html/InstallationGuide.html
  inflating: hypersistence-optimizer-2.1.1-trial/docs/html/UserGuide.html
  inflating: hypersistence-optimizer-2.1.1-trial/docs/pdf/UserGuide.pdf
  inflating: hypersistence-optimizer-2.1.1-trial/changelog.txt
  inflating: hypersistence-optimizer-2.1.1-trial/LICENSE.txt
  inflating: hypersistence-optimizer-2.1.1-trial/maven-install.bat
  inflating: hypersistence-optimizer-2.1.1-trial/maven-install.sh
  inflating: hypersistence-optimizer-2.1.1-trial/README.txt

The package contains the following resources:

* the lib folder contains the main jar file, as well as the JavaDoc and the Java sources
* the configs folder contains a Java service loader configuration file that is going to be explained in the next steps
* the docs folder contains the Installation and User Guides
* the changelog file contains the release notes for all product versions
* the LICENSE file contains the project license info
* the maven-install scripts allow you to install the Java artifacts in your local Maven repository
* the README file contains a short description of the project

Installation Guide
==================

In order to install Hypersistence Optimizer, you need to read the Installation Guide, which is available both in
HTML and PDF formats in the unzipped package:

* hypersistence-optimizer-2.1.1-trial/docs/pdf/InstallationGuide.pdf
* hypersistence-optimizer-2.1.1-trial/docs/html/InstallationGuide.html

User Guide
==========

After you are done with the Installation Guide, you should read the User Guide too, as it shows how you can configure
Hypersistence Optimizer so that you can get the most out of it.

You can find the User Guide in the docs folder as well:

* hypersistence-optimizer-2.1.1-trial/docs/html/UserGuide.html
* hypersistence-optimizer-2.1.1-trial/docs/pdf/UserGuide.pdf

You can also read all the documentation online if you want, at the following web address:
https://vladmihalcea.com/hypersistence-optimizer/docs/

GitHub repository
=================

There is a GitHub repository you can access the following URL: https://github.com/vladmihalcea/hypersistence-optimizer/

This repository contains examples for Spring Boot, Spring Framework, Java EE that can help you set up the tool.

If you want to open an issue, either for enhancement proposals or to report a bug, then you can use the Issues section of this
GitHub repository.

Thank you for using Hypersistence Optimizer and stay tuned for more!